/**
 * 
 */
/**
 * 
 */
module aula10_2 {
	requires java.desktop;
}